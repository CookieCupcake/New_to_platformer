import pygame as pg
from os import *

WIDTH,HEIGHT=800,700
FPS=90
window=pg.display.set_mode((WIDTH,HEIGHT))
pg.display.set_caption("Platformer")
pg.font.init()
#paths
pl_path=path.join("assets","MainCharacters","NinjaFrog")
enemy_path=path.join("assets","MainCharacters","VirtualGuy")
block_path=path.join("assets","Terrain","Grass.png")
heart_path=path.join("assets","Items","heart.png")
end_path=path.join("assets","Items","Checkpoints","End","End (Idle).png")
spike_path=path.join("assets","Traps","Spikes","Idle.png")
data=[[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,3,0,0,1,1,0,0,0,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,1,5,0,0,0,0,0,0,0,0,0,0,1,1,5,0,0,0,0,0,0,0,4,0,0],
      [0,0,0,1,0,0,0,0,0,0,0,1,1,0,0,0,1,1,0,0,0,1,0,0,1,0,0],
      [0,0,2,0,0,0,0,0,5,0,0,0,0,5,0,2,0,0,0,0,1,1,5,5,1,1,0],
      [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]],[

      [0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,5,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,5,4,0],
      [0,0,3,0,0,0,1,1,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,1,1,0],
      [0,0,1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,5,1,0,0,0,1,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0],
      [0,0,2,0,0,5,0,0,5,0,0,0,0,0,5,0,0,0,0,5,2,0,0,5,5,5,0],
      [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]],[

      [0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,5,0,0,0,1,0,1,5,1,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,1,0,0,1,0,0,1,0,5,0,1,0,0,0,1,0,0,1,0,4,0,0,0],
      [5,3,0,0,1,5,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,5,1,5,0,0],
      [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]] ]


def get_background(name):
    image = pg.image.load(path.join("assets","Background", name))
    _, _, width, height = image.get_rect()
    for i in range(WIDTH // width + 1):
        for j in range(HEIGHT // height + 1):
            pos = (i * width, j * height)
            window.blit(image, pos)

def load_sprite_sheets(plpath,width,height):
    pl_all_sheets={}
    sheets_list=listdir(plpath)
    for sheet in sheets_list:
        pl_all_sheets[sheet]=[]
        sheet_img=pg.image.load(path.join(plpath,sheet))
        for i in range(sheet_img.get_width()//width):
            img=pg.transform.scale(sheet_img.subsurface(i*width,0,width,height),(100,100)).convert_alpha()
            pl_all_sheets[sheet].append(img)
    return pl_all_sheets

def world(data,enemy_all_sheets):
    blocks=pg.sprite.Group()
    boxs=pg.sprite.Group()
    enemys=pg.sprite.Group()
    for y,a in enumerate(data):
        for x,b in enumerate(a):
            if b==1:#for blocks
                block=Object(block_path,x*100,y*100,100,100)
                blocks.add(block)
            if b==2:#for enemys
                enemy=Enemy(enemy_all_sheets["idle.png"][0],x*100,y*100,100,100,2,enemy_all_sheets)
                enemys.add(enemy)
            if b==3:#for player
                pl_group=pg.sprite.Group()
                pl=Player(pl_all_sheets["idle.png"][0],x*100,y*100,100,100,5,pl_all_sheets)
                pl_group.add(pl)
            if b==4:#for end
                block=Object(end_path,x*100,y*100,100,100)
                boxs.add(block)
            if b==5:#for spike
                block=Object(spike_path,x*100,y*100,100,100)
                boxs.add(block)

    return blocks,enemys,pl,pl_group,boxs

def draw(pl,enemys,blocks,scroll,boxs,level):
    pl.draw(scroll)
    font2=pg.font.Font(None,50)
    txt=font2.render("Level:"+str(level+1),True,(0,0,0))
    window.blit(txt,(WIDTH-150,0))
    for enemy in enemys:
        window.blit(enemy.image,(enemy.rect.x-scroll,enemy.rect.y))
    for block in blocks:
        window.blit(block.image,(block.rect.x-scroll,block.rect.y))
    for box in boxs:
        window.blit(box.image,(box.rect.x-scroll,box.rect.y))
    for i in range(pl.health):
        heart=pg.transform.scale(pg.image.load(heart_path),(50,50)).convert_alpha()
        window.blit(heart,(i*50,0))

def boxs_collision(boxs,blocks,enemys,pl,pl_group,level,scroll):
    for box in boxs :
        if pl.mask.overlap(box.mask,(box.rect.x-pl.rect.x,box.rect.y-pl.rect.y)):
            if box.image_name==end_path:
                if level<len(data)-1 :
                    level+=1
                else:
                    level=0
                blocks.empty()
                enemys.empty()
                boxs.empty()
                pl_group.empty()
                blocks,enemys,pl,pl_group,boxs=world(data[level],enemy_all_sheets)
                scroll=0
            if box.image_name==spike_path:
                pl.health=0
    return boxs,blocks,enemys,pl,pl_group,level,scroll
pl_all_sheets=load_sprite_sheets(pl_path,32,32)
enemy_all_sheets=load_sprite_sheets(enemy_path,32,32)
#class
class Player(pg.sprite.Sprite):
    def __init__(self,image,x,y,width,height,speed,pl_all_sheets):
        super().__init__()
        self.animation_count=0
        self.status="idle.png"
        self.image=pg.transform.scale(image,(width,height)).convert_alpha()
        self.width=width
        self.height=height
        self.health=5
        self.rect=self.image.get_rect()
        self.rect.x=x
        self.rect.y=y
        self.mask=pg.mask.from_surface(self.image)
        self.x_vel=0
        self.y_vel=0
        self.fall_count=0
        self.jump_count=0
        self.direction="Right"
        self.speed=speed
        self.animation_speed=0.4
        self.sheets=pl_all_sheets

    def draw(self,scroll):
        window.blit(self.image,(self.rect.x-scroll,self.rect.y))

    def update_animation(self):
        if not self.status =="hit.png":
            self.status="idle.png"
            if self.x_vel != 0:
                self.animation_speed=0.4
                self.status="run.png"
            if self.y_vel > 0:
                self.animation_speed=0
                self.status="fall.png"
            if self.y_vel < 0:
                self.animation_speed=0
                self.status="jump.png"
            if self.jump_count == 2 and self.y_vel < 0:
                self.animation_speed=0.4
                self.status="double_jump.png"

        if round(self.animation_count) >= len(pl_all_sheets[self.status]):
            self.animation_count=0
            self.status="idle.png"
        self.image=self.sheets[self.status][round(self.animation_count)].convert_alpha()
        if self.direction == "Left" :
            self.image=pg.transform.flip(self.image,True,False)
        self.animation_count+=self.animation_speed
        self.mask=pg.mask.from_surface(self.image)

    def move(self):
        key=pg.key.get_pressed()
        if key[pg.K_d]:
            self.x_vel=self.speed
            self.direction="Right"
        if key[pg.K_a]:
            self.x_vel=-self.speed
            self.direction="Left"

    def update(self):

        self.update_animation()
        self.fall_count+=1
        self.y_vel+=min(1,(self.fall_count*2)//60)
        self.rect.x+=self.x_vel
        self.rect.y+=self.y_vel
        self.x_vel=0


    def collisions(self,enemys,blocks):
        for block in blocks:
            if block.rect.colliderect(self.rect.x+self.x_vel,self.rect.y,self.width,self.height):
                self.x_vel=0
            #if self.mask.overlap(block.mask,(block.rect.x-self.rect.x+self.x_vel,block.rect.y-self.rect.y)):
            if block.rect.colliderect(self.rect.x,self.rect.y+self.y_vel,self.width,self.height):
                if self.y_vel>0:
                    self.rect.bottom=block.rect.top
                    self.animation_count=0
                    self.y_vel=0
                    self.fall_count=0
                    self.jump_count=0
                elif self.y_vel<0 :
                    self.rect.top=block.rect.bottom
                    self.animation_count=0
                    self.y_vel*=-1
        if pg.sprite.spritecollideany(self, enemys, collided = None) and self.status!="hit.png" :
            self.health-=1
            self.status="hit.png"
            self.animation_speed=0.3


class Enemy(Player):
    def __init__(self,img,x,y,width,height,speed,enemy_all_sheets):
        super().__init__(img,x,y,width,height,speed,enemy_all_sheets)
    def enemy_move(self):
        if self.direction=="Right":
            self.x_vel=self.speed
        if self.direction=="Left":
            self.x_vel=-self.speed
        if self.rect.right >= WIDTH:
            self.direction="Left"
            self.x_vel=-self.speed
        if self.rect.left <= 0:
            self.direction="Right"
            self.x_vel=self.speed
        
class Object(pg.sprite.Sprite):
    def __init__(self,image_name,x,y,width,height):
        super().__init__()
        self.image=pg.transform.scale(pg.image.load(image_name),(width,height)).convert_alpha()
        self.image_name=image_name
        self.rect=self.image.get_rect()
        self.mask=pg.mask.from_surface(self.image)
        self.rect.x=x
        self.rect.y=y
        self.width=width
        self.height=height
        
    def reset(self,scroll):
        window.blit(self.image,(self.rect.x+scroll,self.rect.y))

def game(window):
    level=0
    finish=False
    clock=pg.time.Clock()
    scroll=0
    scroll_area_width=200
    blocks,enemys,pl,pl_group,boxs=world(data[level],enemy_all_sheets)
    restart_btn=Object(path.join("assets","Menu","Buttons","Restart.png"),WIDTH//2-50,HEIGHT//2-50,100,100)
    run=True
    while run:
        clock.tick(FPS)
        for e in pg.event.get():
                if e.type == pg.QUIT:
                    run=False
                if e.type == pg.KEYDOWN:
                    if e.key == pg.K_SPACE and pl.jump_count < 2:
                        pl.y_vel=-4
                        pl.fall_count=0
                        pl.jump_count+=1
        if finish==False:
            pl.move()
            if (pl.rect.right - scroll >= WIDTH-scroll_area_width and pl.x_vel>0) or (pl.rect.left - scroll <= scroll_area_width and pl.x_vel<0):
                scroll+=pl.x_vel
            pl.collisions(enemys,blocks)
            pl.update()
            
            for enemy in enemys:
                enemy.enemy_move()
                enemy.collisions(pl_group,blocks)
                enemy.update()
            get_background("Brown.png")
            boxs,blocks,enemys,pl,pl_group,level,scroll=boxs_collision(boxs,blocks,enemys,pl,pl_group,level,scroll)
            draw(pl,enemys,blocks,scroll,boxs,level)
            
            if pl.health <= 0 or pl.rect.y > HEIGHT :
                window.blit(restart_btn.image,(restart_btn.rect.x,restart_btn.rect.y))
                finish=True
            
        if restart_btn.rect.collidepoint(pg.mouse.get_pos()) and pg.mouse.get_pressed()[0] and finish ==True:
            finish=False
            level=0
            blocks.empty()
            enemys.empty()
            pl_group.empty()
            blocks,enemys,pl,pl_group,boxs=world(data[level],enemy_all_sheets)
            scroll=0

        pg.display.update()
game(window)